package com.example.flowableportal.admin;

import com.example.flowableportal.dto.*;
import com.example.flowableportal.util.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.flowable.engine.HistoryService;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
class AdminTaskServiceImpl implements AdminTaskService {

    private final TaskService taskService;
    private final HistoryService historyService;

    @Override
    public PagedResponse<TaskDto> searchTasks(String candidateGroup, String state, int page, int size) {
        var query = taskService.createTaskQuery();

        if (candidateGroup != null && !candidateGroup.isBlank()) query.taskCandidateGroup(candidateGroup);
        if ("CLAIMABLE".equalsIgnoreCase(state)) query.taskUnassigned();
        if ("ASSIGNED".equalsIgnoreCase(state)) query.taskAssigned();

        long total = query.count();
        List<Task> tasks = query.orderByTaskCreateTime().desc().listPage(page * size, size);

        List<TaskDto> dtos = tasks.stream()
                .map(t -> DtoMapper.toTaskDto(t, getVariables(t.getProcessInstanceId())))
                .toList();

        PagedResponse<TaskDto> response = new PagedResponse<>();
        response.setTotal(total);
        response.setContent(dtos);
        return response;
    }

    private Map<String, Object> getVariables(String processInstanceId) {
        if (processInstanceId == null) return Collections.emptyMap();
        try {
            List<?> variables = historyService.createHistoricVariableInstanceQuery()
                    .processInstanceId(processInstanceId)
                    .list();
            
            Map<String, Object> result = new HashMap<>();
            for (Object var : variables) {
                try {
                    // Use reflection to get variable name and value
                    java.lang.reflect.Method getNameMethod = var.getClass().getMethod("getVariableName");
                    java.lang.reflect.Method getValueMethod = var.getClass().getMethod("getValue");
                    String name = (String) getNameMethod.invoke(var);
                    Object value = getValueMethod.invoke(var);
                    result.put(name, value);
                } catch (Exception e) {
                    // Skip if reflection fails
                }
            }
            return result;
        } catch (Exception e) {
            return Collections.emptyMap();
        }
    }
}

