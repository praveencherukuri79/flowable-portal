package com.example.flowableportal.admin;

import com.example.flowableportal.dto.*;
import com.example.flowableportal.util.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.flowable.engine.*;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
@RequiredArgsConstructor
class AdminRuntimeServiceImpl implements AdminRuntimeService {

    private final RepositoryService repositoryService;
    private final HistoryService historyService;
    private final RuntimeService runtimeService;
    private final ManagementService managementService;

    @Override
    public List<ProcessDefinitionDto> getProcessDefinitions() {
        return repositoryService.createProcessDefinitionQuery()
                .latestVersion()
                .list()
                .stream()
                .map(DtoMapper::toProcessDefinitionDto)
                .toList();
    }

    @Override
    public PagedResponse<ProcessInstanceDto> searchProcessInstances(String definitionKey, String state, int page, int size) {
        var query = historyService.createHistoricProcessInstanceQuery();

        if (definitionKey != null && !definitionKey.isBlank()) {
            query.processDefinitionKey(definitionKey);
        }
        if ("RUNNING".equalsIgnoreCase(state)) query.unfinished();
        if ("COMPLETED".equalsIgnoreCase(state)) query.finished();

        long total = query.count();
        List<HistoricProcessInstance> results = query.orderByProcessInstanceStartTime().desc().listPage(page * size, size);

        List<HistoricProcessInstanceDto> content = results.stream()
                .map(pi -> DtoMapper.toHistoricProcessInstanceDto(pi, getVariables(pi.getId())))
                .toList();
        
        // Convert HistoricProcessInstanceDto to ProcessInstanceDto
        List<ProcessInstanceDto> processInstanceDtos = new ArrayList<>();
        for (HistoricProcessInstanceDto hpi : content) {
            ProcessInstanceDto dto = new ProcessInstanceDto();
            dto.setId(hpi.getId());
            dto.setProcessDefinitionId(hpi.getProcessDefinitionId());
            dto.setProcessDefinitionKey(hpi.getProcessDefinitionKey());
            dto.setBusinessKey(hpi.getBusinessKey());
            dto.setStartUserId(hpi.getStartUserId());
            dto.setStartTime(hpi.getStartTime() != null ? hpi.getStartTime().toString() : null);
            String endTimeStr = hpi.getEndTime() != null ? hpi.getEndTime().toString() : null;
            dto.setEndTime(endTimeStr);
            dto.setStatusFromEndTime(endTimeStr);
            dto.setVariables(hpi.getVariables());
            dto.setTenantId(hpi.getTenantId());
            processInstanceDtos.add(dto);
        }

        PagedResponse<ProcessInstanceDto> response = new PagedResponse<>();
        response.setTotal(total);
        response.setContent(processInstanceDtos);
        return response;
    }

    @Override
    public List<EventLogDto> getEventLogs(int limit) {
        try {
            // Try to get event logs - this feature might not be available in all Flowable versions
            List<?> entries = managementService.getEventLogEntries(0L, (long) limit);
            return entries.stream()
                    .map(entry -> DtoMapper.toEventLogDto(entry))
                    .toList();
        } catch (Exception e) {
            // Event log might not be enabled or available, return empty list
            return new ArrayList<>();
        }
    }

    @Override
    public String generateProcessDiagramSvg(String processInstanceId) {
        ProcessInstance pi = runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        if (pi == null) throw new RuntimeException("Process instance not found: " + processInstanceId);

        try {
            InputStream svgStream = managementService.executeCommand(
                new org.flowable.engine.impl.cmd.GetDeploymentProcessDiagramCmd(pi.getProcessDefinitionId())
            );
            if (svgStream != null) {
                byte[] svg = svgStream.readAllBytes();
                svgStream.close();
                return new String(svg, StandardCharsets.UTF_8);
            }
        } catch (IOException e) {
            throw new RuntimeException("Error reading diagram", e);
        }
        return "";
    }

    private Map<String, Object> getVariables(String processInstanceId) {
        try {
            List<?> variables = historyService.createHistoricVariableInstanceQuery()
                    .processInstanceId(processInstanceId)
                    .list();
            
            Map<String, Object> result = new HashMap<>();
            for (Object var : variables) {
                try {
                    // Use reflection to get variable name and value
                    java.lang.reflect.Method getNameMethod = var.getClass().getMethod("getVariableName");
                    java.lang.reflect.Method getValueMethod = var.getClass().getMethod("getValue");
                    String name = (String) getNameMethod.invoke(var);
                    Object value = getValueMethod.invoke(var);
                    result.put(name, value);
                } catch (Exception e) {
                    // Skip if reflection fails
                }
            }
            return result;
        } catch (Exception e) {
            return new HashMap<>();
        }
    }
}

