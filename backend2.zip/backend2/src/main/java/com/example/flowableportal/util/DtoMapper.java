package com.example.flowableportal.util;

import com.example.flowableportal.dto.*;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.repository.Deployment;
import org.flowable.engine.repository.Model;
import org.flowable.engine.repository.ProcessDefinition;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DtoMapper {

    public static ProcessDefinitionDto toProcessDefinitionDto(ProcessDefinition d) {
        ProcessDefinitionDto dto = new ProcessDefinitionDto();
        dto.setId(d.getId());
        dto.setKey(d.getKey());
        dto.setName(d.getName());
        dto.setCategory(d.getCategory());
        dto.setDescription(d.getDescription());
        dto.setVersion(d.getVersion());
        dto.setDeploymentId(d.getDeploymentId());
        dto.setResourceName(d.getResourceName());
        dto.setDiagramResourceName(d.getDiagramResourceName());
        dto.setSuspended(d.isSuspended());
        dto.setTenantId(d.getTenantId());
        return dto;
    }

    public static ProcessInstanceDto toProcessInstanceDto(ProcessInstance pi, Map<String, Object> vars) {
        ProcessInstanceDto dto = new ProcessInstanceDto();
        dto.setId(pi.getId());
        dto.setProcessDefinitionId(pi.getProcessDefinitionId());
        dto.setProcessDefinitionKey(pi.getProcessDefinitionKey());
        dto.setBusinessKey(pi.getBusinessKey());
        dto.setStartUserId(pi.getStartUserId());
        dto.setStartTime(pi.getStartTime() != null ? pi.getStartTime().toString() : null);
        dto.setStatus(pi.isSuspended() ? "SUSPENDED" : "ACTIVE");
        dto.setVariables(vars);
        // ProcessInstance doesn't have getActivityIds() directly, use empty list
        dto.setActiveActivityIds(new ArrayList<>());
        dto.setSuspended(pi.isSuspended());
        dto.setTenantId(pi.getTenantId());
        return dto;
    }

    public static HistoricProcessInstanceDto toHistoricProcessInstanceDto(HistoricProcessInstance pi, Map<String, Object> vars) {
        HistoricProcessInstanceDto dto = new HistoricProcessInstanceDto();
        dto.setId(pi.getId());
        dto.setProcessDefinitionId(pi.getProcessDefinitionId());
        dto.setProcessDefinitionKey(pi.getProcessDefinitionKey());
        dto.setBusinessKey(pi.getBusinessKey());
        dto.setStartUserId(pi.getStartUserId());
        dto.setStartTime(pi.getStartTime());
        dto.setEndTime(pi.getEndTime());
        dto.setDurationInMillis(pi.getDurationInMillis());
        dto.setDeleteReason(pi.getDeleteReason());
        dto.setVariables(vars);
        dto.setTenantId(pi.getTenantId());
        return dto;
    }

    public static TaskDto toTaskDto(Task t, Map<String, Object> vars) {
        TaskDto dto = new TaskDto();
        dto.setId(t.getId());
        dto.setName(t.getName());
        dto.setDescription(t.getDescription());
        dto.setAssignee(t.getAssignee());
        dto.setOwner(t.getOwner());
        dto.setDelegationState(t.getDelegationState() != null ? t.getDelegationState().toString() : null);
        dto.setProcessInstanceId(t.getProcessInstanceId());
        dto.setProcessDefinitionId(t.getProcessDefinitionId());
        dto.setExecutionId(t.getExecutionId());
        dto.setTaskDefinitionKey(t.getTaskDefinitionKey());
        dto.setCreateTime(t.getCreateTime());
        dto.setDueDate(t.getDueDate());
        dto.setPriority(t.getPriority());
        dto.setCategory(t.getCategory());
        dto.setFormKey(t.getFormKey());
        dto.setVariables(vars);
        dto.setTenantId(t.getTenantId());
        return dto;
    }

    // HistoricTaskInstance mapping - using reflection for compatibility
    public static HistoricTaskInstanceDto toHistoricTaskInstanceDto(Object t, Map<String, Object> vars) {
        HistoricTaskInstanceDto dto = new HistoricTaskInstanceDto();
        try {
            java.lang.reflect.Method getId = t.getClass().getMethod("getId");
            java.lang.reflect.Method getName = t.getClass().getMethod("getName");
            java.lang.reflect.Method getAssignee = t.getClass().getMethod("getAssignee");
            java.lang.reflect.Method getProcessInstanceId = t.getClass().getMethod("getProcessInstanceId");
            java.lang.reflect.Method getStartTime = t.getClass().getMethod("getStartTime");
            java.lang.reflect.Method getEndTime = t.getClass().getMethod("getEndTime");
            
            dto.setId((String) getId.invoke(t));
            dto.setName((String) getName.invoke(t));
            dto.setAssignee((String) getAssignee.invoke(t));
            dto.setProcessInstanceId((String) getProcessInstanceId.invoke(t));
            dto.setStartTime((Date) getStartTime.invoke(t));
            dto.setEndTime((Date) getEndTime.invoke(t));
            dto.setVariables(vars);
        } catch (Exception e) {
            // If reflection fails, set basic values
        }
        return dto;
    }

    public static DeploymentDto toDeploymentDto(Deployment d) {
        DeploymentDto dto = new DeploymentDto();
        dto.setId(d.getId());
        dto.setName(d.getName());
        dto.setDeploymentTime(d.getDeploymentTime());
        dto.setCategory(d.getCategory());
        dto.setTenantId(d.getTenantId());
        return dto;
    }

    public static ModelDto toModelDto(Model m) {
        ModelDto dto = new ModelDto();
        dto.setId(m.getId());
        dto.setName(m.getName());
        dto.setKey(m.getKey());
        dto.setCategory(m.getCategory());
        dto.setCreateTime(m.getCreateTime());
        dto.setLastUpdateTime(m.getLastUpdateTime());
        dto.setVersion(m.getVersion());
        dto.setMetaInfo(m.getMetaInfo());
        dto.setDeploymentId(m.getDeploymentId());
        // Model editor source methods may not be available in all versions
        try {
            java.lang.reflect.Method getEditorSourceValueId = m.getClass().getMethod("getEditorSourceValueId");
            java.lang.reflect.Method getEditorSourceExtraValueId = m.getClass().getMethod("getEditorSourceExtraValueId");
            dto.setEditorSourceValueId((String) getEditorSourceValueId.invoke(m));
            dto.setEditorSourceExtraValueId((String) getEditorSourceExtraValueId.invoke(m));
        } catch (Exception e) {
            // Methods not available
        }
        dto.setTenantId(m.getTenantId());
        return dto;
    }

    public static EventLogDto toEventLogDto(Object e) {
        EventLogDto dto = new EventLogDto();
        try {
            java.lang.reflect.Method getLogNumber = e.getClass().getMethod("getLogNumber");
            java.lang.reflect.Method getTimeStamp = e.getClass().getMethod("getTimeStamp");
            java.lang.reflect.Method getType = e.getClass().getMethod("getType");
            java.lang.reflect.Method getProcessDefinitionId = e.getClass().getMethod("getProcessDefinitionId");
            java.lang.reflect.Method getProcessInstanceId = e.getClass().getMethod("getProcessInstanceId");
            java.lang.reflect.Method getExecutionId = e.getClass().getMethod("getExecutionId");
            java.lang.reflect.Method getData = e.getClass().getMethod("getData");
            
            dto.setId(String.valueOf(getLogNumber.invoke(e)));
            dto.setTimestamp((Date) getTimeStamp.invoke(e));
            dto.setType((String) getType.invoke(e));
            dto.setProcessDefinitionId((String) getProcessDefinitionId.invoke(e));
            dto.setProcessInstanceId((String) getProcessInstanceId.invoke(e));
            dto.setExecutionId((String) getExecutionId.invoke(e));
            byte[] data = (byte[]) getData.invoke(e);
            dto.setData(data != null ? new String(data, StandardCharsets.UTF_8) : null);
        } catch (Exception ex) {
            dto.setId("unknown");
            dto.setTimestamp(new Date());
            dto.setType("UNKNOWN");
        }
        return dto;
    }

}

