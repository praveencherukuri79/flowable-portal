package com.example.flowableportal.admin;

import com.example.flowableportal.dto.MetricsDto;

public interface AdminMetricsService {
    MetricsDto getMetrics();
}

