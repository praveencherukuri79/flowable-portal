package com.example.flowableportal.dto;

import lombok.Data;
import java.util.Date;
import java.util.Map;

@Data
public class HistoricTaskInstanceDto {
    private String id;
    private String name;
    private String description;
    private String assignee;
    private String owner;
    private String processInstanceId;
    private String processDefinitionId;
    private String taskDefinitionKey;
    private Date startTime;
    private Date endTime;
    private Long durationInMillis;
    private Date claimTime;
    private String deleteReason;
    private int priority;
    private Date dueDate;
    private String category;
    private Map<String, Object> variables;
    private String tenantId;
}

