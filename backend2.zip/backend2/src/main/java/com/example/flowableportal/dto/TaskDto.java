package com.example.flowableportal.dto;

import lombok.Data;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
public class TaskDto {
    private String id;
    private String name;
    private String description;
    private String assignee;
    private String owner;
    private String delegationState;
    private String processInstanceId;
    private String processDefinitionId;
    private String executionId;
    private String taskDefinitionKey;
    private Date createTime;
    private Date dueDate;
    private int priority;
    private String category;
    private String formKey;
    private List<String> candidateUsers;
    private List<String> candidateGroups;
    private Map<String, Object> variables;
    private List<String> comments;
    private List<String> attachments;
    private String suspended;
    private String tenantId;
}

