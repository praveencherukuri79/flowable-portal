package com.example.flowableportal.dto;

import lombok.Data;
import java.util.Map;

@Data
public class EngineInfoDto {
    private String name;
    private String version;
    private Map<String, Object> properties;
    private Map<String, Object> databaseInfo;
}

