package com.example.flowableportal.dto;

import lombok.Data;

@Data
public class ProcessDefinitionDto {
    private String id;
    private String key;
    private String name;
    private String description;
    private int version;
    private String category;
    private String deploymentId;
    private String resourceName;
    private String diagramResourceName;
    private boolean suspended;
    private String tenantId;
}

