package com.example.flowableportal.dto;

import lombok.Data;
import java.util.List;

@Data
public class PagedResponse<T> {
    private List<T> content;
    private long total;
    private int page;
    private int size;
    private int totalPages;
}

