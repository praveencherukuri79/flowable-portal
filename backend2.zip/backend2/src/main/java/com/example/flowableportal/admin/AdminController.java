package com.example.flowableportal.admin;

import com.example.flowableportal.dto.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@Tag(name = "Admin APIs", description = "Flowable Admin Portal Controller")
public class AdminController {

    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    private final AdminRuntimeService runtimeService;
    private final AdminTaskService taskService;
    private final AdminMetricsService metricsService;

    @GetMapping("/definitions")
    @Operation(summary = "Get all deployed process definitions")
    public List<ProcessDefinitionDto> listDefinitions() {
        log.info("Fetching all process definitions");
        return runtimeService.getProcessDefinitions();
    }

    @GetMapping("/instances/search")
    @Operation(summary = "Search process instances")
    public PagedResponse<ProcessInstanceDto> searchInstances(
            @RequestParam(required = false) String definitionKey,
            @RequestParam(required = false) String state,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size) {
        log.info("Searching process instances");
        return runtimeService.searchProcessInstances(definitionKey, state, page, size);
    }

    @GetMapping("/tasks/search")
    @Operation(summary = "Search tasks")
    public PagedResponse<TaskDto> searchTasks(
            @RequestParam(required = false) String candidateGroup,
            @RequestParam(required = false) String state,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size) {
        log.info("Searching tasks");
        return taskService.searchTasks(candidateGroup, state, page, size);
    }

    @GetMapping("/events/search")
    @Operation(summary = "Fetch event logs")
    public List<EventLogDto> listEvents(@RequestParam(defaultValue = "100") int limit) {
        log.info("Fetching last {} event logs", limit);
        return runtimeService.getEventLogs(limit);
    }

    @GetMapping("/metrics")
    @Operation(summary = "Get dashboard metrics")
    public MetricsDto getMetrics() {
        log.info("Building dashboard metrics");
        return metricsService.getMetrics();
    }

    @GetMapping(value = "/diagram/{processInstanceId}", produces = "image/svg+xml")
    @Operation(summary = "Generate runtime process diagram")
    public String getDiagram(@PathVariable String processInstanceId) {
        log.info("Generating process diagram for instance: {}", processInstanceId);
        return runtimeService.generateProcessDiagramSvg(processInstanceId);
    }
}

