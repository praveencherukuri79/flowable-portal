package com.example.flowableportal.dto;

import lombok.Data;
import java.util.Date;
import java.util.Map;

@Data
public class HistoricProcessInstanceDto {
    private String id;
    private String processDefinitionId;
    private String processDefinitionKey;
    private String businessKey;
    private String startUserId;
    private Date startTime;
    private Date endTime;
    private Long durationInMillis;
    private String deleteReason;
    private Map<String, Object> variables;
    private String tenantId;
}

