package com.example.flowableportal.dto;

import lombok.Data;
import java.util.List;

@Data
public class MetricsDto {
    private long runningInstances;
    private long completedInstances;
    private long totalTasks;
    private List<DailyCount> instancesByDay;
    private List<StateCount> tasksByState;
    private List<DurationMetric> avgDurationByDefinition;

    @Data
    public static class DailyCount {
        private String day;
        private long count;
    }

    @Data
    public static class StateCount {
        private String state;
        private long count;
    }

    @Data
    public static class DurationMetric {
        private String definitionKey;
        private double minutes;
    }
}

