package com.example.flowableportal.service.impl;

import com.example.flowableportal.dto.ProcessInstanceDto;
import com.example.flowableportal.service.FlowableProcessService;
import com.example.flowableportal.util.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.runtime.ProcessInstance;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class FlowableProcessServiceImpl implements FlowableProcessService {

    private final RuntimeService runtimeService;
    private final HistoryService historyService;

    @Override
    @Transactional
    public ProcessInstanceDto startProcess(String processKey, Map<String, Object> variables) {
        ProcessInstance instance = runtimeService.startProcessInstanceByKey(processKey, variables);
        Map<String, Object> vars = runtimeService.getVariables(instance.getId());
        return DtoMapper.toProcessInstanceDto(instance, vars);
    }

    @Override
    @Cacheable("processes")
    public List<ProcessInstanceDto> getActiveProcesses() {
        List<ProcessInstance> instances = runtimeService.createProcessInstanceQuery()
                .active()
                .list();
        
        return instances.stream()
                .map(pi -> {
                    Map<String, Object> vars = runtimeService.getVariables(pi.getId());
                    return DtoMapper.toProcessInstanceDto(pi, vars);
                })
                .toList();
    }

    @Override
    @Cacheable("processes")
    public List<ProcessInstanceDto> getProcessesByKey(String processKey) {
        List<ProcessInstance> instances = runtimeService.createProcessInstanceQuery()
                .processDefinitionKey(processKey)
                .list();
        
        return instances.stream()
                .map(pi -> {
                    Map<String, Object> vars = runtimeService.getVariables(pi.getId());
                    return DtoMapper.toProcessInstanceDto(pi, vars);
                })
                .toList();
    }

    @Override
    @Cacheable("processes")
    public ProcessInstanceDto getProcessInstance(String processInstanceId) {
        ProcessInstance instance = runtimeService.createProcessInstanceQuery()
                .processInstanceId(processInstanceId)
                .singleResult();
        
        if (instance == null) {
            throw new RuntimeException("Process instance not found: " + processInstanceId);
        }
        
        Map<String, Object> vars = runtimeService.getVariables(instance.getId());
        return DtoMapper.toProcessInstanceDto(instance, vars);
    }

    @Override
    @Transactional
    public void suspendProcess(String processInstanceId) {
        runtimeService.suspendProcessInstanceById(processInstanceId);
    }

    @Override
    @Transactional
    public void activateProcess(String processInstanceId) {
        runtimeService.activateProcessInstanceById(processInstanceId);
    }

    @Override
    @Transactional
    public void deleteProcess(String processInstanceId) {
        runtimeService.deleteProcessInstance(processInstanceId, "Deleted via API");
    }

    @Override
    @Cacheable("history")
    public Map<String, Object> getProcessStatistics() {
        Map<String, Object> stats = new HashMap<>();
        long activeCount = runtimeService.createProcessInstanceQuery().count();
        long completedCount = historyService.createHistoricProcessInstanceQuery().finished().count();
        
        stats.put("activeProcesses", activeCount);
        stats.put("completedProcesses", completedCount);
        stats.put("totalProcesses", activeCount + completedCount);
        
        return stats;
    }
}

