package com.example.flowableportal.service.impl;

import com.example.flowableportal.dto.TaskDto;
import com.example.flowableportal.service.FlowableTaskService;
import com.example.flowableportal.util.DtoMapper;
import lombok.RequiredArgsConstructor;
import org.flowable.engine.HistoryService;
import org.flowable.engine.TaskService;
import org.flowable.task.api.Task;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class FlowableTaskServiceImpl implements FlowableTaskService {

    private final TaskService taskService;
    private final HistoryService historyService;

    @Override
    @Cacheable("tasks")
    public List<TaskDto> getTasksForUser(String user) {
        List<Task> tasks = taskService.createTaskQuery()
                .taskCandidateOrAssigned(user)
                .list();
        
        return tasks.stream()
                .map(t -> DtoMapper.toTaskDto(t, getVariables(t.getProcessInstanceId())))
                .toList();
    }

    @Override
    @Transactional
    public void claimTask(String taskId, String user) {
        taskService.claim(taskId, user);
    }

    @Override
    @Transactional
    public void completeTask(String taskId, Map<String, Object> variables) {
        taskService.complete(taskId, variables);
    }

    @Override
    @Transactional
    public void reassignTask(String taskId, String newUser) {
        Task task = taskService.createTaskQuery().taskId(taskId).singleResult();
        if (task != null) {
            taskService.setAssignee(taskId, newUser);
        }
    }

    @Override
    @Transactional
    public void delegateTask(String taskId, String delegateUser) {
        taskService.delegateTask(taskId, delegateUser);
    }

    private Map<String, Object> getVariables(String processInstanceId) {
        if (processInstanceId == null) return Collections.emptyMap();
        try {
            List<?> variables = historyService.createHistoricVariableInstanceQuery()
                    .processInstanceId(processInstanceId)
                    .list();
            
            Map<String, Object> result = new HashMap<>();
            for (Object var : variables) {
                try {
                    java.lang.reflect.Method getNameMethod = var.getClass().getMethod("getVariableName");
                    java.lang.reflect.Method getValueMethod = var.getClass().getMethod("getValue");
                    String name = (String) getNameMethod.invoke(var);
                    Object value = getValueMethod.invoke(var);
                    result.put(name, value);
                } catch (Exception e) {
                    // Skip if reflection fails
                }
            }
            return result;
        } catch (Exception e) {
            return Collections.emptyMap();
        }
    }
}

