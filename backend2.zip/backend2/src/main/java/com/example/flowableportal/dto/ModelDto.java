package com.example.flowableportal.dto;

import lombok.Data;
import java.util.Date;

@Data
public class ModelDto {
    private String id;
    private String name;
    private String key;
    private String category;
    private Date createTime;
    private Date lastUpdateTime;
    private int version;
    private String metaInfo;
    private String deploymentId;
    private String editorSourceValueId;
    private String editorSourceExtraValueId;
    private String tenantId;
}

