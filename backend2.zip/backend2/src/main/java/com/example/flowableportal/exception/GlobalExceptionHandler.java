package com.example.flowableportal.exception;

import org.flowable.engine.FlowableException;
import org.flowable.engine.FlowableObjectNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler({FlowableException.class, FlowableObjectNotFoundException.class})
    public ResponseEntity<Map<String, Object>> handleFlowableException(FlowableException e) {
        log.error("Flowable error: {}", e.getMessage(), e);
        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", LocalDateTime.now());
        error.put("status", HttpStatus.BAD_REQUEST.value());
        error.put("error", "Flowable Error");
        error.put("message", e.getMessage());
        error.put("errorCode", "FLOWABLE_ERROR");
        return ResponseEntity.badRequest().body(error);
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    public ResponseEntity<Map<String, Object>> handleValidationException(MethodArgumentNotValidException e) {
        log.error("Validation error: {}", e.getMessage());
        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", LocalDateTime.now());
        error.put("status", HttpStatus.BAD_REQUEST.value());
        error.put("error", "Validation Error");
        error.put("message", "Invalid input provided. Please check your data.");
        error.put("errorCode", "VALIDATION_ERROR");
        return ResponseEntity.badRequest().body(error);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Map<String, Object>> handleTypeMismatchException(MethodArgumentTypeMismatchException e) {
        log.error("Type mismatch error: {}", e.getMessage());
        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", LocalDateTime.now());
        error.put("status", HttpStatus.BAD_REQUEST.value());
        error.put("error", "Type Mismatch Error");
        error.put("message", "Invalid parameter type: " + e.getName());
        error.put("errorCode", "TYPE_MISMATCH_ERROR");
        return ResponseEntity.badRequest().body(error);
    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String, Object>> handleRuntimeException(RuntimeException e) {
        log.error("Runtime error: {}", e.getMessage(), e);
        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", LocalDateTime.now());
        
        String message = e.getMessage();
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        String errorCode = "INTERNAL_ERROR";
        
        if (message != null) {
            if (message.contains("not found") || message.contains("Not Found")) {
                status = HttpStatus.NOT_FOUND;
                errorCode = "RESOURCE_NOT_FOUND";
            } else if (message.contains("access denied") || message.contains("Access Denied")) {
                status = HttpStatus.FORBIDDEN;
                errorCode = "ACCESS_DENIED";
            }
        }
        
        error.put("status", status.value());
        error.put("error", status.getReasonPhrase());
        error.put("message", message != null ? message : "An unexpected error occurred");
        error.put("errorCode", errorCode);
        return ResponseEntity.status(status).body(error);
    }
}

