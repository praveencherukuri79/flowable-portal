package com.example.flowableportal.dto;

import lombok.Data;
import java.util.Date;

@Data
public class EventLogDto {
    private String id;
    private Date timestamp;
    private String type;
    private String processDefinitionId;
    private String processInstanceId;
    private String executionId;
    private String data;
}

