package com.example.flowableportal.admin;

import com.example.flowableportal.dto.*;

public interface AdminTaskService {
    PagedResponse<TaskDto> searchTasks(String candidateGroup, String state, int page, int size);
}

