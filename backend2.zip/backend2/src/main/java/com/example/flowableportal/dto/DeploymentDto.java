package com.example.flowableportal.dto;

import lombok.Data;
import java.util.Date;
import java.util.List;

@Data
public class DeploymentDto {
    private String id;
    private String name;
    private Date deploymentTime;
    private String category;
    private String tenantId;
    private List<String> resourceNames;
}

