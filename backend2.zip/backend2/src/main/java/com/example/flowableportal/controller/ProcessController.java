package com.example.flowableportal.controller;

import com.example.flowableportal.dto.ProcessInstanceDto;
import com.example.flowableportal.service.FlowableProcessService;
import com.example.flowableportal.util.ResponseUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/process")
@RequiredArgsConstructor
@Tag(name = "Process Management", description = "Process Instance Management APIs")
public class ProcessController {

    private final FlowableProcessService processService;

    @PostMapping("/start/{processKey}")
    @Operation(summary = "Start process", description = "Start a new process instance with the given process key and variables")
    @CacheEvict(value = "processes", allEntries = true)
    public ResponseEntity<ProcessInstanceDto> startProcess(
            @PathVariable String processKey,
            @RequestBody(required = false) Map<String, Object> variables) {
        ProcessInstanceDto instance = processService.startProcess(processKey, variables != null ? variables : Map.of());
        return ResponseEntity.ok(instance);
    }

    @GetMapping("/active")
    @Operation(summary = "Get active processes", description = "Retrieve all currently active process instances")
    public ResponseEntity<List<ProcessInstanceDto>> getActiveProcesses() {
        return ResponseEntity.ok(processService.getActiveProcesses());
    }

    @GetMapping("/by-key/{processKey}")
    @Operation(summary = "Get processes by key", description = "Retrieve all process instances for a specific process definition key")
    public ResponseEntity<List<ProcessInstanceDto>> getProcessesByKey(@PathVariable String processKey) {
        return ResponseEntity.ok(processService.getProcessesByKey(processKey));
    }

    @GetMapping("/{processInstanceId}")
    @Operation(summary = "Get process instance", description = "Retrieve a specific process instance by ID")
    public ResponseEntity<ProcessInstanceDto> getProcessInstance(@PathVariable String processInstanceId) {
        return ResponseEntity.ok(processService.getProcessInstance(processInstanceId));
    }

    @PostMapping("/suspend/{processInstanceId}")
    @Operation(summary = "Suspend process", description = "Suspend a running process instance")
    @CacheEvict(value = "processes", allEntries = true)
    public ResponseEntity<Map<String, Object>> suspendProcess(@PathVariable String processInstanceId) {
        processService.suspendProcess(processInstanceId);
        return ResponseEntity.ok(ResponseUtils.successResponse("Process suspended successfully", null));
    }

    @PostMapping("/activate/{processInstanceId}")
    @Operation(summary = "Activate process", description = "Activate a suspended process instance")
    @CacheEvict(value = "processes", allEntries = true)
    public ResponseEntity<Map<String, Object>> activateProcess(@PathVariable String processInstanceId) {
        processService.activateProcess(processInstanceId);
        return ResponseEntity.ok(ResponseUtils.successResponse("Process activated successfully", null));
    }

    @DeleteMapping("/{processInstanceId}")
    @Operation(summary = "Delete process", description = "Delete a process instance")
    @CacheEvict(value = "processes", allEntries = true)
    public ResponseEntity<Map<String, Object>> deleteProcess(@PathVariable String processInstanceId) {
        processService.deleteProcess(processInstanceId);
        return ResponseEntity.ok(ResponseUtils.successResponse("Process deleted successfully", null));
    }

    @GetMapping("/statistics")
    @Operation(summary = "Get process statistics", description = "Retrieve statistics about process instances")
    public ResponseEntity<Map<String, Object>> getProcessStatistics() {
        return ResponseEntity.ok(processService.getProcessStatistics());
    }
}

