package com.example.flowableportal.controller;

import com.example.flowableportal.dto.TaskDto;
import com.example.flowableportal.service.FlowableTaskService;
import com.example.flowableportal.util.ResponseUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/flowable/task")
@RequiredArgsConstructor
@Tag(name = "Task Management", description = "Flowable Task Management APIs")
public class FlowableTaskController {

    private final FlowableTaskService taskService;

    @GetMapping("/user/{user}")
    @Operation(summary = "Get tasks for user", description = "Retrieve all tasks assigned to or available for a specific user")
    public ResponseEntity<List<TaskDto>> getTasksForUser(@PathVariable String user) {
        return ResponseEntity.ok(taskService.getTasksForUser(user));
    }

    @PostMapping("/assign/{taskId}")
    @Operation(summary = "Claim/assign task", description = "Assign a task to a user")
    @CacheEvict(value = "tasks", allEntries = true)
    public ResponseEntity<Map<String, Object>> assignTask(
            @PathVariable String taskId,
            @RequestParam String user) {
        taskService.claimTask(taskId, user);
        return ResponseEntity.ok(ResponseUtils.successResponse("Task assigned successfully", null));
    }

    @PostMapping("/reassign/{taskId}")
    @Operation(summary = "Reassign task", description = "Reassign a task to a different user")
    @CacheEvict(value = "tasks", allEntries = true)
    public ResponseEntity<Map<String, Object>> reassignTask(
            @PathVariable String taskId,
            @RequestParam String newUser) {
        taskService.reassignTask(taskId, newUser);
        return ResponseEntity.ok(ResponseUtils.successResponse("Task reassigned successfully", null));
    }

    @PostMapping("/delegate/{taskId}")
    @Operation(summary = "Delegate task", description = "Delegate a task to another user")
    @CacheEvict(value = "tasks", allEntries = true)
    public ResponseEntity<Map<String, Object>> delegateTask(
            @PathVariable String taskId,
            @RequestParam String delegateUser) {
        taskService.delegateTask(taskId, delegateUser);
        return ResponseEntity.ok(ResponseUtils.successResponse("Task delegated successfully", null));
    }

    @PostMapping("/complete/{taskId}")
    @Operation(summary = "Complete task", description = "Complete a task with optional variables")
    @CacheEvict(value = {"tasks", "processes"}, allEntries = true)
    public ResponseEntity<Map<String, Object>> completeTask(
            @PathVariable String taskId,
            @RequestBody(required = false) Map<String, Object> variables) {
        taskService.completeTask(taskId, variables != null ? variables : Map.of());
        return ResponseEntity.ok(ResponseUtils.successResponse("Task completed successfully", null));
    }
}

