package com.example.flowableportal.service;

import com.example.flowableportal.dto.ProcessInstanceDto;
import java.util.List;
import java.util.Map;

public interface FlowableProcessService {
    ProcessInstanceDto startProcess(String processKey, Map<String, Object> variables);
    List<ProcessInstanceDto> getActiveProcesses();
    List<ProcessInstanceDto> getProcessesByKey(String processKey);
    ProcessInstanceDto getProcessInstance(String processInstanceId);
    void suspendProcess(String processInstanceId);
    void activateProcess(String processInstanceId);
    void deleteProcess(String processInstanceId);
    Map<String, Object> getProcessStatistics();
}

