package com.example.flowableportal.dto;

import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
public class ProcessInstanceDto {
    private String id;
    private String processDefinitionId;
    private String processDefinitionKey;
    private String businessKey;
    private String startUserId;
    private String startTime;
    private String endTime;
    private String status;
    private Map<String, Object> variables;
    private List<String> activeActivityIds;
    private List<String> completedActivityIds;
    private String diagramUrl;
    private String tenantId;
    private boolean suspended;
    private String name;
    private String description;
    
    // Helper method to set status based on endTime
    public void setStatusFromEndTime(String endTime) {
        this.endTime = endTime;
        this.status = (endTime == null) ? "ACTIVE" : "COMPLETED";
    }
}

